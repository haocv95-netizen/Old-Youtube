package com.example.oldyoutubelite;

import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private EditText queryBox, apiKeyBox;
    private LinearLayout results;
    private Button searchButton;
    private static final int BLUE = 0xFF1565C0;
    private static final int PAD = 16;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // Simple synchronous networking keeps this starter dependency-free.
        // Search is triggered only after the user taps the button.
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());
        buildUi();
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, float size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(0xFF202124);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(12), dp(12), dp(12), dp(8));
        page.setBackgroundColor(0xFFF7F8FA);

        TextView title = text("YouTube Lite", 23, true);
        title.setTextColor(BLUE);
        page.addView(title);

        TextView info = text("Ứng dụng nhẹ cho Android 5+. Tìm video bằng YouTube Data API; video sẽ mở trong ứng dụng YouTube hoặc trình duyệt.", 14, false);
        page.addView(info);

        apiKeyBox = new EditText(this);
        apiKeyBox.setSingleLine(true);
        apiKeyBox.setHint("Dán YouTube Data API key (bắt buộc để tìm kiếm)");
        apiKeyBox.setTextSize(14);
        page.addView(apiKeyBox, new LinearLayout.LayoutParams(-1, dp(52)));

        queryBox = new EditText(this);
        queryBox.setSingleLine(true);
        queryBox.setHint("Nhập từ khóa tìm video");
        queryBox.setTextSize(16);
        page.addView(queryBox, new LinearLayout.LayoutParams(-1, dp(52)));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);

        searchButton = new Button(this);
        searchButton.setText("Tìm video");
        actions.addView(searchButton, new LinearLayout.LayoutParams(0, dp(48), 1));

        Button loginButton = new Button(this);
        loginButton.setText("Đăng nhập YouTube");
        actions.addView(loginButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        page.addView(actions);

        ScrollView scroll = new ScrollView(this);
        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        results.setPadding(0, dp(8), 0, dp(8));
        scroll.addView(results);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(page);

        addMessage("Nhập API key và từ khóa, sau đó bấm “Tìm video”.");
        searchButton.setOnClickListener(v -> searchVideos());
        loginButton.setOnClickListener(v -> openYouTubeHome());
    }

    private void addMessage(String message) {
        results.removeAllViews();
        results.addView(text(message, 14, false));
    }

    private void searchVideos() {
        final String key = apiKeyBox.getText().toString().trim();
        final String query = queryBox.getText().toString().trim();
        if (key.isEmpty()) {
            Toast.makeText(this, "Hãy nhập YouTube Data API key.", Toast.LENGTH_LONG).show();
            return;
        }
        if (query.isEmpty()) {
            Toast.makeText(this, "Hãy nhập từ khóa tìm kiếm.", Toast.LENGTH_SHORT).show();
            return;
        }

        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(queryBox.getWindowToken(), 0);
        searchButton.setEnabled(false);
        addMessage("Đang tìm kiếm…");

        HttpURLConnection connection = null;
        try {
            String urlText = "https://www.googleapis.com/youtube/v3/search"
                    + "?part=snippet&type=video&maxResults=15"
                    + "&q=" + URLEncoder.encode(query, "UTF-8")
                    + "&key=" + URLEncoder.encode(key, "UTF-8");
            connection = (HttpURLConnection) new URL(urlText).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(12000);
            int code = connection.getResponseCode();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream(),
                    "UTF-8"));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) body.append(line);
            reader.close();

            if (code < 200 || code >= 300) {
                JSONObject error = new JSONObject(body.toString());
                String message = error.optJSONObject("error") != null
                        ? error.optJSONObject("error").optString("message", "Lỗi API")
                        : "Lỗi HTTP " + code;
                addMessage("Không tìm kiếm được: " + message
                        + "\nKiểm tra API key, bật YouTube Data API v3 và hạn mức API.");
                return;
            }

            JSONObject response = new JSONObject(body.toString());
            JSONArray items = response.optJSONArray("items");
            results.removeAllViews();
            if (items == null || items.length() == 0) {
                addMessage("Không tìm thấy video.");
                return;
            }

            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.getJSONObject(i);
                JSONObject id = item.optJSONObject("id");
                JSONObject snippet = item.optJSONObject("snippet");
                if (id == null || snippet == null) continue;
                String videoId = id.optString("videoId", "");
                if (videoId.isEmpty()) continue;
                String title = snippet.optString("title", "Video");
                String channel = snippet.optString("channelTitle", "Kênh YouTube");
                String description = snippet.optString("description", "");
                addVideoCard(title, channel, description, videoId);
            }
        } catch (Exception e) {
            addMessage("Lỗi kết nối: " + e.getMessage()
                    + "\nKiểm tra Internet và API key rồi thử lại.");
        } finally {
            if (connection != null) connection.disconnect();
            searchButton.setEnabled(true);
        }
    }

    private void addVideoCard(String title, String channel, String description, String videoId) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(6), dp(10), dp(6));
        card.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.setMargins(0, dp(4), 0, dp(4));
        results.addView(card, cardParams);

        TextView titleView = text(title, 16, true);
        card.addView(titleView);
        card.addView(text(channel, 13, false));
        if (!description.isEmpty()) {
            String shortDescription = description.length() > 180
                    ? description.substring(0, 180) + "…" : description;
            card.addView(text(shortDescription, 12, false));
        }
        Button play = new Button(this);
        play.setText("Mở video");
        card.addView(play, new LinearLayout.LayoutParams(-1, dp(44)));
        View.OnClickListener open = v -> openVideo(videoId);
        play.setOnClickListener(open);
        card.setOnClickListener(open);
    }

    private void openVideo(String videoId) {
        Uri uri = Uri.parse("https://www.youtube.com/watch?v=" + videoId);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Không tìm thấy ứng dụng/trình duyệt để mở video.", Toast.LENGTH_LONG).show();
        }
    }

    private void openYouTubeHome() {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/"));
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Không mở được YouTube. Hãy cài trình duyệt tương thích.", Toast.LENGTH_LONG).show();
        }
    }
}
